package TestNg;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviderExample {
	
	
	@DataProvider(name="TestData")
	public Object[][] DataMethod(){
		return new Object[][] {{"Test1"},{"Test2"}};
	}
	
	@Test(dataProvider="TestData")
	public void fetchData(String values) {
				
		System.out.println(values);
		
	}

}
