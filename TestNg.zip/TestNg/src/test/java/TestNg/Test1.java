package TestNg;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.AfterMethod;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;

public class Test1 {
	
	WebDriver driver;
	
  //@Test(groups="smoke")
	@Test(priority=0)
  public void testA() {
	  
	  driver.findElement(By.xpath("//a[@href='/en/book-a-free-demo/']/following::button[.='Book a Free Demo']")).click();
	  String str = driver.getTitle();
	  System.out.println(str);
  }
  
  //@Test(enabled=false)
  //@Test(dependsOnMethods="testA",groups={"Regression","smoke"})
	@Test(priority=1)
	//@Test(priority=1,enabled=false)
  public void testB() {
	  
	  driver.findElement(By.xpath("//a[@href='/en/contact-sales/']/following::button[.='Contact Sales']")).click();
	  String str = driver.getTitle();
	  System.out.println(str);
  }

  @BeforeClass(alwaysRun=true)
  @Parameters("browser")
  public void beforeClass(String browser) {
	  String projectPath = System.getProperty("user.dir");
	  System.setProperty("webdriver.http.factory", "jdk-http-client");
		
		if(browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
			//WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}else if(browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.firefox.driver", projectPath + "/Drivers/FireFoxDriver/firefox.exe");
			//WebDriverManager.chromedriver().setup();
			driver = new FirefoxDriver();
		}else if(browser.equalsIgnoreCase("IE")) {
			System.setProperty("webdriver.edge.driver", projectPath + "/Drivers/EdgeDriver/msedgedriver.exe");
			driver = new EdgeDriver();
		}
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.orangehrm.com/");
  }

  @AfterClass(alwaysRun=true)
  public void afterClass() {
	  
	  driver.close();
  }

}
