package TestNg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class ReporterLogs {
	
	WebDriver driver;
	
	@Test
	public void LaunchURL() {
		driver.get("https://www.orangehrm.com/");
		Reporter.log("URL launched", true);
	}
	
	@Test
	public void clickOnBook() {
		driver.findElement(By.xpath("//a[@href='/en/book-a-free-demo/']/following::button[.='Book a Free Demo']")).click();
		Reporter.log("Clicked on Book a Free Demo \n", true);
		
		String title = driver.getTitle();
		Reporter.log("Current page title is "+title, true);
	}
	
	@Test
	public void clickOnContact() {
		driver.findElement(By.xpath("//a[@href='/en/contact-sales/']/following::button[.='Contact Sales']")).click();
		Reporter.log("Clicked on Contact Sales \n", true);
		
		String title = driver.getTitle();
		Reporter.log("Current page title is "+title, true);
	}
	
	
	
	@BeforeClass(alwaysRun = true)
	public void beforeClass() {
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");

		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));		
	}

	@AfterClass(alwaysRun = true)
	public void afterClass() {

		driver.close();
	}

}
