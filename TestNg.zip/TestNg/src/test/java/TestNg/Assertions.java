package TestNg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Assertions {
	WebDriver driver;

	@Test(enabled=true)
	public void hardAssertion() {
		driver.findElement(By.xpath("//a[@href='/en/book-a-free-demo/']/following::button[.='Book a Free Demo']"))
				.click();
		String str = driver.getTitle();
		System.out.println(str);
		// hard assertion--> if it fails here it terminates the whole method and wont go further steps	
		//Assert.assertEquals(str, "Google");
		Assert.assertEquals(str, "Book Your Free Demo | OrangeHRM");

		driver.findElement(By.xpath("//a[@href='/en/contact-sales/']/following::button[.='Contact Sales']")).click();
		String str1 = driver.getTitle();
		System.out.println(str1);
		
		//assert boolean
		boolean flag=false;
		if(str1.contains("OrangeHRM")) {
			flag=true;
		}
		Assert.assertTrue(flag);

	}
	
	@Test(enabled=false)
	public void softAssertion() {
		
		driver.findElement(By.xpath("//a[@href='/en/book-a-free-demo/']/following::button[.='Book a Free Demo']")).click();
		String str = driver.getTitle();
		System.out.println(str);
		// soft assertion--> it wont terminate the executiuon even though it fails it continue to the next steps	
		
		SoftAssert softassert = new SoftAssert();
		softassert.assertEquals(str, "google","Verifying actuall with expected");

		//Assert.assertEquals(str, "Book Your Free Demo | OrangeHRM");

		driver.findElement(By.xpath("//a[@href='/en/contact-sales/']/following::button[.='Contact Sales']")).click();
		String str1 = driver.getTitle();
		System.out.println(str1);
		softassert.assertEquals(str1, "Get in Touch with OrangeHRM Sales | OrangeHRM","Verifying actual with expected");
		
		softassert.assertAll();

	}

	@BeforeClass(alwaysRun = true)
	public void beforeClass() {
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");

		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.orangehrm.com/");
	}

	@AfterClass(alwaysRun = true)
	public void afterClass() {

		driver.close();
	}

}
